package com.ultimates.grs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrsApplicationTests {

	@Test
	void contextLoads() {
	}

}
