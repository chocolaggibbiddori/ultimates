package com.ultimates.grs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GrsApplication {

	public static void main(String[] args) {
		SpringApplication.run(GrsApplication.class, args);
	}

}
